import type { CostPerformanceChartProps } from "./types";
import "./evidence-theme.css";
import "./chart.css";
/** Draw only after visibility is established. Server HTML remains fully visible. */
export declare function useEvidenceChartMotion(animated: boolean): import("react").RefObject<HTMLDivElement | null>;
export declare function CostPerformanceChart({ title, subtitle, series, xAxis, yAxis, note, animated, className }: CostPerformanceChartProps): import("react/jsx-runtime").JSX.Element;
