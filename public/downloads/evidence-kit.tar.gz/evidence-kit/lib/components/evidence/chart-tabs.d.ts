import type { ChartTab } from "./types";
export declare function ChartTabs({ tabs, className }: {
    tabs: readonly ChartTab[];
    className?: string;
}): import("react/jsx-runtime").JSX.Element | null;
