import type { ResponseComparisonProps } from "./types";
export declare function ResponseComparison({ examples, className }: ResponseComparisonProps): import("react/jsx-runtime").JSX.Element;
