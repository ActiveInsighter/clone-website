import type { ReactNode } from "react";
import type { BenchmarkTableProps, ComparisonValue } from "./types";
import "./comparison-table.css";
interface ComparisonTableViewportProps {
    caption: string;
    children: ReactNode;
    className?: string;
}
/** Owns scrolling so the shadcn table container never overflows the page. */
export declare function ComparisonTableViewport({ caption, children, className, }: ComparisonTableViewportProps): import("react/jsx-runtime").JSX.Element;
/** Render caller-supplied display strings verbatim, including currency precision. */
export declare function ComparisonCellContent({ cell }: {
    cell?: ComparisonValue;
}): import("react/jsx-runtime").JSX.Element;
export declare function BenchmarkTable({ columns, rows, highlightColumn, caption, note, className, }: BenchmarkTableProps): import("react/jsx-runtime").JSX.Element;
export {};
