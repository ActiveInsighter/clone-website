import type { RichTextBlock } from "./types";
import "./editorial-widgets.css";
export interface RichTextProps {
    blocks: readonly RichTextBlock[];
    className?: string;
}
/** Reject protocols and disguised schemes rather than delegating URL safety to the DOM. */
export declare function safeRichTextHref(value: string): string | undefined;
export declare function RichText({ blocks, className }: RichTextProps): import("react/jsx-runtime").JSX.Element;
