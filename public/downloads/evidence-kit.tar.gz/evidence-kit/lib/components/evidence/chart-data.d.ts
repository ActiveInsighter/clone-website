import type { ChartAxis, ChartPoint, ChartSeries } from "./types";
/** Reject values a numeric/logarithmic scale cannot represent without changing data. */
export declare function isChartPointValid(point: ChartPoint, xAxis: ChartAxis, yAxis: ChartAxis): boolean;
export declare function validateChartAxis(axis: ChartAxis): string | null;
export declare function getChartTicks(axis: ChartAxis): number[];
export declare function getChartSeries(series: readonly ChartSeries[], xAxis: ChartAxis, yAxis: ChartAxis): ChartSeries[];
/** Percent values are percentage points (38.5 means 38.5%), never normalized. */
export declare function formatChartValue(value: number, axis: Pick<ChartAxis, "format">, tick?: boolean): string;
