import type { TestimonialTabsProps } from "./types";
export declare function TestimonialTabs({ items, label, className }: TestimonialTabsProps): import("react/jsx-runtime").JSX.Element;
