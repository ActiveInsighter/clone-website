import type { ReactNode } from "react";
import type { ChartAxis } from "./types";
export interface BenchmarkBarDatum {
    id: string;
    label: string;
    value: number;
    color?: string;
    highlight?: boolean;
}
export interface BenchmarkBarChartProps {
    title: string;
    subtitle?: string;
    data: readonly BenchmarkBarDatum[];
    valueAxis: ChartAxis;
    valueLabel?: string;
    note?: ReactNode;
    animated?: boolean;
    className?: string;
}
/** A categorical alternative for comparing caller-supplied benchmark values. */
export declare function BenchmarkBarChart({ title, subtitle, data, valueAxis, valueLabel, note, animated, className }: BenchmarkBarChartProps): import("react/jsx-runtime").JSX.Element;
