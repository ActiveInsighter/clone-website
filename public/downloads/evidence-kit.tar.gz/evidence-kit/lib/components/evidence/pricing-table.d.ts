import type { PricingTableProps } from "./types";
export declare function PricingTable({ columns, rows, caption, className }: PricingTableProps): import("react/jsx-runtime").JSX.Element;
