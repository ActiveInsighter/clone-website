import { copyFile, mkdir, readdir } from "node:fs/promises"
import { createRequire } from "node:module"
import { dirname, join } from "node:path"
import { fileURLToPath } from "node:url"
import { spawnSync } from "node:child_process"
const root = dirname(fileURLToPath(import.meta.url))
const require = createRequire(import.meta.url)
const result = spawnSync(process.execPath, [require.resolve("typescript/bin/tsc"), "-p", join(root, "tsconfig.json")], { stdio: "inherit" })
if (result.status !== 0) process.exit(result.status || 1)
for (const file of await readdir(join(root, "src/components/evidence"))) {
  if (!file.endsWith(".css")) continue
  await mkdir(join(root, "lib/components/evidence"), { recursive: true })
  await copyFile(join(root, "src/components/evidence", file), join(root, "lib/components/evidence", file))
}
