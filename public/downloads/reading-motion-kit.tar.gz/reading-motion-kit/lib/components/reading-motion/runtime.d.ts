/** One event hub and animation frame for all mounted reading effects. */
export interface MotionSubscriber {
    measure: () => void;
    paint: (time: number, reduced: boolean) => boolean;
}
export declare function requestMotionFrame(remeasure?: boolean): void;
export declare function subscribeMotion(entry: MotionSubscriber): () => void;
