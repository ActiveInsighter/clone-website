import type { MotionPainter } from "./use-reading-motion";
export declare function createHighlightPainter(root: HTMLElement): MotionPainter;
export declare function createParagraphPainter(root: HTMLElement, customOffset?: {
    x: number;
    y: number;
}, customRotation?: number): MotionPainter;
