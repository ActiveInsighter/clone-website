import type { ReadingMotionOptions } from "./types";
export interface MotionPainter {
    measure: () => void;
    draw: (progress: number, reduced: boolean) => void;
    clear: () => void;
}
export declare function useReadingMotion(options: ReadingMotionOptions, createPainter: (root: HTMLElement) => MotionPainter): import("react").RefObject<HTMLElement | null>;
