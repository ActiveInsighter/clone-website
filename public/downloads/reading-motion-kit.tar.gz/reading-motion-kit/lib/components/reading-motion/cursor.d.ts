/** Decorative cursor; never hides or replaces the reader's real pointer. */
export declare function ReadingCursor({ show }: {
    show?: boolean;
}): import("react/jsx-runtime").JSX.Element;
