import type { MotionParagraphProps } from "./types";
export declare function MotionParagraph({ children, className, as: Tag, offset, rotation, trigger, active, playKey, duration, delay, once, showCursor, scrollRoot, autoScroll, onComplete, onProgress, ref, ...props }: MotionParagraphProps): import("react/jsx-runtime").JSX.Element;
