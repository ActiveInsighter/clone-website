import type { CursorHighlightProps } from "./types";
export declare function CursorHighlight({ children, className, color, trigger, active, playKey, duration, delay, once, showCursor, scrollRoot, autoScroll, onComplete, onProgress, ref, ...props }: CursorHighlightProps): import("react/jsx-runtime").JSX.Element;
