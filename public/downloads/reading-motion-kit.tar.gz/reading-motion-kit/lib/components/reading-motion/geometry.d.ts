export interface LineRect {
    x: number;
    y: number;
    width: number;
    height: number;
}
export declare const clamp: (value: number, min?: number, max?: number) => number;
/** Range rectangles from nested rich text, coalesced into visual lines. */
export declare function mergeLineRects(rects: readonly LineRect[]): LineRect[];
export declare function measureLines(text: HTMLElement, origin: DOMRect): LineRect[];
/** Entry at the bottom of the root through arrival at its midpoint. */
export declare function scrollProgress(top: number, height: number, rootTop: number, rootHeight: number): number;
export declare function highlightFrame(lines: readonly LineRect[], progress: number, rtl?: boolean): {
    fills: number[];
    x: number;
    y: number;
    rotation: number;
    scale: number;
    opacity: number;
};
export declare function paragraphFrame(progress: number, offset: {
    x: number;
    y: number;
}, rotation: number, rtl?: boolean): {
    x: number;
    y: number;
    rotation: number;
    opacity: number;
    scale: number;
};
